<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="aspects/coding.jfif">
    <link rel="stylesheet" href="aspects/bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Challenges</title>
</head>
<body>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</html>

<?php

function generateTasks($sectionContent, $sectionTitle) {
    echo "<div class='row text-center'>";
    echo "<h1>  $sectionTitle  </h1>";
    echo "<ul class = 'd-flex justify-content-evenly'>";
    foreach ($sectionContent as $link) {
        echo '<li class = "list-unstyled"><a href="' . $link['url'] . '" class = "btn"><button class = "btn btn-outline-dark">' . $link['text'] . '</button></a></li>';
    }
    echo "</ul>";
    echo "</div>";
}

$iterations = [
    ['url' => 'tasks/whileDo.php', 'text' => 'While Do'],
    ['url' => 'tasks/doWhile.php', 'text' => 'Do While'],
    ['url' => 'tasks/even_numbers.php', 'text' => 'Print Even Numbers'],
    ['url' => 'tasks/multiplication_table_of_5.php', 'text' => 'Multiplication Table Of 5'],
    ['url' => 'tasks/square_of_numbers.php', 'text' => 'Square Of Numbers From 1 To 5'],
    ['url' => 'tasks/timetable_1-12.php', 'text' => 'Multiplication Table From 1 To 12']
];
generateTasks($iterations, 'Iterations');