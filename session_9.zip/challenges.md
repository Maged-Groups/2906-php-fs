# Create the following loops

## Print Numbers from 1 to 10 ✅
- Write a for loop that prints numbers from 1 to 10. (while) 

## Reverse Countdown ✅
- print numbers from 10 down to 1. (do-while) 

## Print Even Numbers up to 20 ✅
-  Prints all even numbers from 1 to 20 starting the count from 1. (for)

## Multiplication Table of 5 ✅
- Write a for loop that prints the multiplication table of 5 up to 5 × 10. (for)

## Print Square of Numbers from 1 to 5 ✅ 
- print the square of numbers from 1 to 5. (while)
 

## create the timetable 1 - 12 ✅
- Print the math timetable from 1 to 12 (optional)