<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../aspects/coding.jfif">
    <link rel="stylesheet" href="../aspects/bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Print Even Numbers From 1 To 20</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php 


## Print Even Numbers up to 20
//Prints all even numbers from 1 to 20 starting the count from 1. (for)
echo "<body class = 'container text-bg-dark w-100 p-2'>";

function printEven($start, $end) {
    $color = '';
 
    for ( ;$start <= $end; $start++) {

        if ($start % 2 === 0) {
            $color = "green";
            echo "<h1>This number is <span style = 'color: $color;'>$start</span>. It's an even </h1>" . "<hr />";
        }

        else {
            $color = "red";
            echo "<h1>The number is <span style = 'color: $color;'>$start</span>, it's not an even number</h1>";
        }
    }
}
printEven(1, 20);

echo "<div class = 'd-flex justify-content-between'>";
echo "<a href = '../index.php' class = 'w-25'><button class = 'btn btn-outline-warning w-100' >Return Back</button></a>";
echo "<button class = 'btn btn-outline-warning w-25' data-bs-toggle='offcanvas' data-bs-target='#toggle'> Show The Code </button>";

echo "<div class='offcanvas offcanvas-center text-bg-danger' data-bs-scroll='true' tabindex='-1' id='toggle'>";
echo "<div class='offcanvas-header'>";
echo "<h5 class='offcanvas-title' id='toggle'>For Loop</h5>";
echo "<button type='button' class='btn-close' data-bs-dismiss='offcanvas' aria-label='Close'></button>";
echo "</div>";

echo "<div class='offcanvas-xl'>";
echo "<textarea rows='15' cols='120' class = 'text-bg-success'>";
echo "function printEven($ start, $ end) {
    $ color = '';
 
    for ( ;$ start <= $ end; $ start++) {

        if ($ start % 2 === 0) {
            $ color = 'green';
            echo '<h1>This number is <span style = 'color: $ color;'>$ start</span>. It's an even </h1>' . '<hr />';
        }

        else {
            $ color = 'red';
            echo '<h1>The number is <span style = 'color: $ color;'>$ start</span>, its not an even number</h1>';
        }
    }
}
printEven(1, 20);";
echo "</textarea>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</body>";





