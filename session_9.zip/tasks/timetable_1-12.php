<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../aspects/coding.jfif">
    <link rel="stylesheet" href="../aspects/bootstrap.css">
    <title>Time Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">


</head>
<body class="body p-2 text-bg-dark">

<div class="accordion accordion-flush" id="accordionFlushExample">

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed fs-4" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne">
        For Loop
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body text-bg-info h4">
        <textarea class="text-bg-primary" rows="10" cols="100">
          function timeTable($x, $z) {
            for(; $x <= $z; $x++) {
              for($y = 1; $y <= $z; $y++){
                $multi = $x * $y ;
                echo "<h1>x = $x , y = $y</h1>";
                echo "<h1>$x * $y = $multi</h1>";
              }
            }   
          }
          timeTable(1, 12);
        </textarea>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed fs-4" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo">
        While Do
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body text-bg-dark h4">
        <textarea class = "text-bg-secondry" rows="10" cols="70">
          function timeTable($x, $z) {
            while($x <= $z) {
              $y = 1;
              while($y <= $z){
                $multi = $x * $y ;
                echo "<h1>x = $x , y = $y</h1>";
                echo "<h1>$x * $y = $multi</h1>";
                $y++;
              }
              $x++;
            }
          }   
          timeTable(1, 12);
      </textarea>
    </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed fs-4" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree">
        Do While
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body text-bg-warning h4">
        <textarea class = "text-bg-success" rows="10" cols="70">
          function timeTable($x, $z) {
            Do {
              $y = 1;
              Do {
                $multi = $x * $y ;
                echo "<h1>x = $x , y = $y</h1>";
                echo "<h1>$x * $y = $multi</h1>";
                $y++;
              }
              while($y <= $z);
              $x++;
          }
            while($x <= $z);
          }   
          timeTable(1, 12);
        </textarea>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed fs-4" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour">
        Table Design
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body text-bg-light h4">
        <textarea class="text-bg-danger" rows="10" cols="100">
          echo "<table  class = 'table table-dark'>"; 
          echo "<div class = 'text-center h3 w-100 p-2 text-bg-dark'> x * y </div>";

          for ($row = 1; $row <= 12; $row++) {  
              echo "<tr class ='h6'>";

          for ($col = 1; $col <= 12; $col++) {
          $multiply = $col * $row; //computing values
          echo "<td> $col * $row = $multiply </td> ";
          }
          echo "</tr>";
          }
          echo "</table>"; 
        </textarea>
      </div>
    </div>
  </div>

</div>
 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</html>

<?php

echo "<table  class = 'table table-dark'>"; //creating the border outline
echo "<div class = 'text-center h3 w-100 p-2 text-bg-dark'> x * y </div>";

for ($row = 1; $row <= 12; $row++) {  // first loop
    echo "<tr class ='h6'>";

for ($col = 1; $col <= 12; $col++) { //2nd loop
  $multiply = $col * $row; //computing values
  echo "<td> $col * $row = $multiply </td> ";
  }
  echo "</tr>";
}
echo "</table>"; //closing the table

echo "<div class = 'd-flex text-center justify-content-around align-items-center'>";
echo "<a href = '../index.php' class= 'w-100 p-3'><button class = 'btn btn-outline-light w-100 p-3' >Return Back</button></a>";
"</div>";
