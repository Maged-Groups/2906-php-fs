<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Challenges-1</title>
        <link rel="icon" href="coding.jfif">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <nav>
            <a href="#one"><button>1#Simple Greeting</button></a>
            <a href="#two"><button>2#Age Message</button></a>
            <a href="#three"><button>3#Sum of Two Numbers</button></a>
            <a href="#four"><button>4#Multiplication Table</button></a>
            <a href="#five"><button>5#Full Name</button></a>
            <a href="#six"><button>6#Person Introduction</button></a>
            <a href="#seven"><button>7#Simple Discount</button></a>
            <a href="#eight"><button>8#Rectangle Area</button></a>
            <a href="#nine"><button>9#Simple Calculator</button></a>
            <a href="#ten"><button>10#Temperature Converter</button></a>
            <a href="#eleven"><button>11#Circle Area</button></a>
            <a href="#twelve"><button>12#Discount Price</button></a>
            <a href="#thirteen"><button>13#Concat Strings</button></a>
            <a href="#fourteen"><button>14#Exchange Rate</button></a>
            <a href="#fivteen"><button>15#Add Prefix to Name</button></a>
            <a href="#sixteen"><button>16#Length of a String</button></a>
            <a href="#seventeen"><button>17#Personalized Welcome</button></a>
            <a href="#eighteen"><button>18#Power of Number</button></a>
        </nav>

        <div id="parent">
            <div id="one">
                <?php
                        ### 1. **Simple Greeting**
                        // Create a function `greet()` that accepts a name as a parameter and echoes "Hello, [name]!"
                        echo "<h2>Simple greating</h2>";
                        function great($name) {
                            echo "<span>Hello</span><mark> $name</mark> <br>";
                            echo "<br> <hr> <br>";
                        }
                        great(name: "<mark>Ismail</mark>");
                        great(name: "<mark>Mohammed</mark>");
                        great(name: "<mark>Ahmed</mark>");
                        ?>
            </div>

            <div id="two">
                <?php
                    ### 2. **Age Message**
                    //Create a function `displayAge()` that accepts a name and age as parameters and echoes "[name] is [age] years old."
                    echo "<h2>Age Message</h2>";
                    function displayAge($name, $age) {
                        echo "<span><mark>$name</mark> is <mark>$age</mark> years old</span><br>";
                        echo "<br> <hr> <br>";
                    }  
                    displayAge(name: 'Ismail', age: 22);
                    displayAge(name: 'Samir', age: 42);
                    displayAge(name: 'Asmaa', age: 25);
                ?>
            </div>

            <div id="three">
                <?php
                    ### 3. **Sum of Two Numbers**
                    //Create a function `addNumbers()` that accepts two numbers as parameters and echoes their sum.
                    echo "<h2>Sum of Two Numbers</h2>";
                    function addNumbers($num1, $num2) {
                        $value = $num1 + $num2;
                        echo "<span>The sum of <mark> $num1 </mark> and<mark> $num2 </mark> equals </span><mark>$value</mark> <br>";
                        echo "<br> <hr> <br>";
                    }
                    addNumbers(20, 40);
                    addNumbers(89.5, 78.6950);
                    addNumbers(-340, 890);
                ?>
            </div>

            <div id="four">
                <?php
                    ### 4. **Multiplication Table**
                    // Create a function `multiply()` that accepts two parameters: a number and how many times to multiply it. Echo the result of the multiplication.
                    echo "<h2>Multiplication Table</h2>";
                    function multiply($num1, $num2) {
                        $value = $num1 * $num2;
                        echo "<span>The result of multiplying <mark> $num1 </mark> times<mark> $num2 </mark>equals </span><mark>$value</mark> <br>";
                    echo "<br> <hr> <br>";
                    }
                    multiply(num1: 10, num2: 35);
                    multiply(num1: -12, num2: 25.8);
                    multiply(num1: 89, num2: 73.012);
                ?>    
            </div>

            <div id="five">
                <?php
                    ### 5. **Full Name**
                    //Create a function `getFullName()` that accepts first name and last name as parameters and echoes the full name.
                    echo "<h2>Full Name</h2>";
                    function getFullName($firstName, $lastName){
                        $fullName = "<span>Welcome </span> <mark>$firstName </mark> <mark> $lastName</mark>";
                        echo "$fullName <br>";
                        echo "<br> <hr> <br>";
                    }
                    getFullName(firstName: "Ismail", lastName: "Abokhalifa");
                    getFullName(firstName: "Maged", lastName: "Yaseen");
                    getFullName(firstName: "Mona", lastName: "Gamal");
                ?>
            </div>

            <div id="six">
                <?php
                    ### 6. **Person Introduction**
                    //Create a function `introducePerson()` that accepts a name, age, and city as parameters, and echoes a message: "My name is [name], I am [age] years old, and I live in [city]."
                    echo "<h2>Person Introduction</h2>";
                    function introducePerson($name, $age, $city) {
                        echo "<span>My name is <mark> $name </mark>, I'am <mark> $age </mark> years old, and I live in <mark>$city </mark> <br>";
                        echo "<br> <hr> <br>";
                    }
                    introducePerson(name: "AbdulRahman", age: 25, city: "Miami");
                    introducePerson(name: "Somaia", age: 38, city: "Alex West");
                    introducePerson(name: "Alaadin", age: 42, city: "El-Mohandseen");
                ?>
            </div>

            <div id="seven">
                <?php
                    ### 7. **Simple Discount**
                    //Create a function `applyDiscount()` that accepts the original price and a discount percentage as parameters, then echoes the discounted price.
                    echo "<h2>Simple Dicount</h2>";
                    function applyDiscount($oPrice, $disPrecentatge) {
                        $disPrice = $oPrice * $disPrecentatge / 100;
                        echo "<span>The discounted price of that product which its original price is <mark> $oPrice EGP</mark>,<br>
                        and it's for sale <mark> $disPrecentatge %</mark> equals <mark> $disPrice EGP</mark></span><br>";

                        echo "<br> <hr> <br>";
                    }
                    applyDiscount(45800, 35);
                    applyDiscount(890000000, 8);
                    applyDiscount(78950000, 80);
                ?>
            </div>

            <div id="eight">
                <?php
                    ### 8. **Rectangle Area**
                    //Create a function `rectangleArea()` that accepts the width and height of a rectangle as parameters, and echoes the area (width * height).
                    echo "<h2>Rectangle Area</h2>";
                    function rectangleArea($width, $height) {
                        $area = $width * $height;
                        echo "<span>The area of the rectangle which its width is <mark>$width m</mark> and its height is <mark> $height m</mark> equals <mark> $area m<sup>2</sup></mark></span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    rectangleArea(width: 10, height: 15);
                    rectangleArea(width: 13.87, height: 22);
                    rectangleArea(width: 45, height: 64);
                ?>
            </div>

            <div id="nine">
                <?php
                    ### 9. **Simple Calculator**
                    //Create a function `calculate()` that accepts two numbers then echos (addition, subtraction, multiplication, and division) as results.
                    echo "<h2>Simple Calculator</h2>";
                    function calculate($fNum, $sNum) {
                        $add = $fNum + $sNum;
                        $sub = $fNum - $sNum;
                        $multi = $fNum * $sNum;
                        $divi = $fNum / $sNum;
                        echo "<br><span>The addition of <mark> $fNum </mark> and <mark> $sNum </mark> equals <mark> $add </mark></span><br>";
                        echo "<br><span>The subtraction of <mark> $fNum </mark> and <mark> $sNum </mark> equals <mark> $sub </mark></span><br>";
                        echo "<br><span>The multiplication of <mark> $fNum </mark> and <mark> $sNum </mark> equals <mark> $multi </mark></span><br>";
                        echo "<br><span>The division of <mark> $fNum </mark> and <mark> $sNum </mark> equals <mark> $divi </mark></span><br>";
                        echo "<br> <hr> <br>";
                    }
                    calculate(fNum: 10, sNum: 10);
                    calculate(fNum: 789, sNum: 58);
                    calculate(fNum: 57.2, sNum: 23.8);
            ?>
            </div>

            <div id="ten">
                <?php
                    ### 10. **Temperature Converter**
                    //Create a function `convertToCelsius()` that accepts a temperature in Fahrenheit as a parameter and converts it to Celsius (use the formula: (F - 32) * 5/9).
                    echo "<h2>Temperature Converter</h2>";
                    function convertToCelsius($tempInFehrenheight) {
                        $tempInCelsius = ($tempInFehrenheight - 32) * 5/9;
                        echo "<span>The temperature that equals <mark> $tempInFehrenheight °F </mark>is about <mark> $tempInCelsius °C </mark> </span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    convertToCelsius(70);
                    convertToCelsius(32);
                    convertToCelsius(-2);
                ?>
            </div>

            <div id="eleven">
                <?php         
                    ### 11. **Circle Area**
                    //Create a function `circleArea()` that accepts the radius of a circle as a parameter and echoes the area of the circle (3.17 * radius^2).
                    echo "<h2>Circle Area</h2>";
                    function circleArea($radius) {
                        $area = 3.17 * ($radius * $radius);
                        echo "<span>The circle's area which its radius is <mark> $radius cm </mark> equals <mark> $area cm<sup>2</sup></mark></span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    circleArea(12);
                    circleArea(30);
                    circleArea(25.8);
                ?>
            </div>

            <div id="twelve">
                <?php
                    ### 12. **Discount Price**
                    //Create a function `getDiscountedPrice()` that accepts the original price and discount percentage, then echoes the discounted price.
                    echo "<h2>Discount Price</h2>";
                    function getDiscountPrice($oPrice, $discount) {
                        $disPrecentage = $discount / 100;
                        $discountedPrice = $oPrice - ($oPrice * $disPrecentage);
                        echo "<span>The product which costs <mark> $oPrice EGP</mark> has a discount <mark> $discount %</mark></span><br>";
                        echo "<span>After the discount, the price of that product becomes <mark> $discountedPrice EGP</mark></span>.<br>";
                        echo "<br> <hr> <br>";
                    }
                    getDiscountPrice(2000, 15);
                    getDiscountPrice(28000, 18);
                    getDiscountPrice(15970000, 20);
                ?>
            </div>
            
            <div id="thirteen">
                <?php
                    ### 13. **Concat Strings**
                    //Create a function `concatStrings()` that accepts two strings as parameters and echoes their concatenated result.
                    echo "<h2>Concat Strings</h2>";
                    function concatStrings($string1, $string2) {
                        $concat = $string1 . $string2;
                        echo "<span>$concat</span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    concatStrings("Hello ", "Everybody");
                    concatStrings("Welcome", " in a brand new day");
                    concatStrings("Just keep", " smile till your last breath");
                ?>
            </div>

            <div id="fourteen">
                <?php
                    ### 14. **Exchange Rate**
                    //Create a function `convertCurrency()` that accepts an amount in EGP and a conversion rate, and other currency, and echoes the converted amount.
                    echo "<h2>Exchange Rate</h2>";
                    function convertCurrency($amountInEGP) {
                        $currencyInUSD = $amountInEGP / 50.30;
                        echo "<span>The amount of <mark> $amountInEGP EGP </mark> are exchanged to <mark> $currencyInUSD USD</mark></span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    convertCurrency(500);
                    convertCurrency(8900);
                    convertCurrency(458365.150);
                ?>
            </div>

            <div id="fivteen">
                <?php
                    ### 15. **Add Prefix to Name**
                    //Create a function `addPrefix()` that accepts a prefix and a name as parameters and echoes the name with the prefix added.
                    echo "<h2>Add Prefix to Name</h2>";
                    function addPrefix($prefix, $name) {
                        echo "<mark>$prefix  $name</mark> <br>";
                        echo "<br> <hr> <br>";
                    }
                    addPrefix("Dr/", "Hamed");
                    addPrefix("Eng/", "Abdullah");
                    addPrefix("Prof/", "Fatema");
                ?>
            </div>

            <div id="sixteen">
                <?php
                    ### 16. **Length of a String**
                    //Create a function `stringLength()` that accepts a string and echoes the length of the string.
                    echo "<h2>Length of a string</h2>";
                    function stringLength($someWord) {
                        $length = strlen($someWord);
                        echo "<span>The length of this string equals <mark> $length </mark>characters</span> <br>";
                        echo "<br> <hr> <br>";
                    }
                    stringLength("Live Every Single Moment As If It Is The Last One");
                    stringLength("Live With Faith, Strugle And Patiance");
                    stringLength("Live With Love And Evaluate Life");
                ?>
            </div>

            <div id="seventeen">
                <?php
                    ### 17. **Personalized Welcome**
                    //Create a function `welcomeUser()` that accepts a name and a city as parameters, and echoes "Welcome [name] from [city]!"
                    echo "<h2>Personalized Welcome</h2>";
                    function welcomeUser($name, $city) {
                        echo "<span>Welcome <mark> $name </mark> from <mark> $city </mark></span><br>";
                        echo "<br> <hr> <br>";
                    }
                    welcomeUser("Hassan", "Madghashkar");
                    welcomeUser("Shorouk", "Agamy");
                    welcomeUser("Jhon", "New York");
                ?>
            </div>

            <div id="eighteen">
                <?php
                    ### 18. **Power of Number**
                    //Create a function `powerOfNumber()` that accepts a base number and an exponent as parameters, and echoes the result of base raised to the power of exponent.
                    echo "<h2>Power of Number</h2>";
                    function powerOfNumber($baseNumber, $exponent) {
                        $powNumber = $baseNumber ** $exponent;
                        echo "<span>The result of a the power <mark> $exponent </mark>of a number<mark> $baseNumber </mark>equals<mark> $powNumber </mark></span><br>";
                        echo "<br> <hr> <br>";
                    }
                    powerOfNumber(10, 5);
                    powerOfNumber(2, 9);
                    powerOfNumber(78, 12);
                ?>
            </div>
        </div>

    </body>
</html>
<?php
     
