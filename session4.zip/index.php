<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
</head>
<body>
    <header>
        <h1>2906 PHP Full-Stack App</h1>
    </header>

    <nav>
        <a href="/">Home</a>
        <a href="variables.php">Variables</a>
        <a href="variables-01.php">Variables-01</a>
        <a href="functions.php">Functions</a>
    </nav>
</body>
</html>