<?php 


// for next cases, the color should be red => Canclled, Refunded, Complain
// for next cases, the color should be blue => Pending, On Hold, **Postponed
// for next cases, the color should be green => Delivered, Shipped, Reviewed
// handle not matched status

$status = 'Delivered';
$color = '';

$colorChange = match ($status) {
    'Cancelled', 'Refunded', 'Complain' => $color = 'red',
    'Pending', 'On Hold', 'Postponed' => $color = 'blue',
    'Delivered', 'Shipped', 'Reviewed' => $color = 'green',
    default => false
};

echo ($colorChange == false)
? "<h1>Handle not matched status</h1>" 
:"<h2 style = 'color: $colorChange;'>The status is <span style = ' text-decoration: underline; font-size: 30px;'>$status</span></h1>";