<?php


// for next cases, the color should be red => Canclled, Refunded, Complain
// for next cases, the color should be blue => Pending, On Hold, **Postponed
// for next cases, the color should be green => Delivered, Shipped, Reviewed
// handle not matched status

$status = '';
$color = '';

switch ($status) {
    case 'Canclled':
    case 'Refunded':
    case 'Compain':
        $color = 'red';
        break;

    case 'Pending';
    case 'On Hold';
    case 'Postponed';
        $color = 'blue';
        break; 

    case 'Delivered';
    case 'Shipped';
    case 'Reviewed';
        $color = 'green';
        break;

    default:
        $status = false;
}       

echo ($status == false)
? "<h1>Handle not matched status</h1>" 
:"<h3 style = 'color: $color;'>The status is <span style = 'text-decoration: underline;font-size:25px;'>$status</span></h3>";