<?php 


// for next cases, the color should be red => Canclled, Refunded, Complain
// for next cases, the color should be blue => Pending, On Hold, **Postponed
// for next cases, the color should be green => Delivered, Shipped, Reviewed
// handle not matched status


$status = '';
$color = '';

$colorChange = function() {    
    global $status;
    global $color;
    if ($status == 'Cancelled' || $status == 'Refunded' || $status == 'Complain') {
        $color = 'red';
    }
    elseif ($status == 'Pending' || $status == 'On Hold' || $status == 'Postponed') {
        $color = 'blue';
    }
    elseif ($status == 'Delivered' || $status == 'Shipped' || $status == 'Reviewed') {
        $color = 'green';
    }
    else {
        echo "<h1>Handle not matched status</h1>";
    };
    return "<h2 style = 'color: $color;'>The status is <span style = ' text-decoration: underline; font-size: 30px;'>$status</span></h1>";
};
echo $colorChange();    