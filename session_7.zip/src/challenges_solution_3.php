<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session 7</title>
    <link rel="icon" href="../aspects/coding.jfif">
    <link href="../dist/output.css" rel="stylesheet">
</head>
<body class="overscroll-x-contain">

    
    <div class = "relative flex justify-between items-center px-10 py-5 bg-blue-700 text-blue-200 text-xl">
    <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
   bg-indigo-950  text-center transition delay-150 hover:opacity-0 hover:transition-opacity"><h1>Introduction</h1></div>
        <div class = "font-bold">
            <?php
                ### Create a function that introduces someone's name and the country where he/she lives in.
                function introduce($name, $country) {
                    echo "My name is $name, I live in $country." . "<br />";
                }
                introduce('Sam', 'Canada');
                introduce(country: 'USA', name: 'Laila');
                introduce('Omar', 'Egypt');
                introduce(country: 'France', name:'Sophia');
                introduce('Ali', 'UAE');
            ?>
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-gray-500 text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute top-full right-0 rounded-lg p-3 mt-1 shadow-md scale-y-0 group-focus:scale-y-100 origin-bottom duration-200 z-10">
                <pre class = "active text-green-900 bg-green-200 rounded text-left px-5 py-10 w-200">               
        ### Create a function that introduces someone's name
        and the country where he/she lives in.

        function introduce($name, $country) {
            echo "My name is <mark>$name</mark>, I live in <mark>$country</mark>.";
        }
        introduce('Sam', 'Canada');
        introduce(country: 'USA', name: 'Laila');
        introduce('Omar', 'Egypt');
        introduce(country: 'France', name:'Sophia');
        introduce('Ali', 'UAE');
                </pre>
                <a href="" class = " text-amber-100 w-200"><p class = "bg-blue-800">Close</p></a>
            </div>
        </button>    
    </div>
    

    <div class = "relative flex justify-between items-center px-10 py-5 text-amber-200 bg-amber-600 text-xl" >
        <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
        bg-fuchsia-950 text-fuchsia-400 text-center transition delay-150 hover:opacity-0 hover:transition-opacity"><h1>Full Name</h1></div>
        <div class = "font-bold">
            <?php
                //Create a two-parametered function that prints Full Name.
                function fullName($first, $last) {
                    echo "Full Name: $first" . ' ' . "$last." . "<br />";
                }
                fullName('John', 'Doe');
                fullName('Sara', 'Smith');
                fullName('Ali', 'Khan');
                fullName('Nour', 'Fahmy');
                fullName('David','Brown');
            ?>
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-gray-500 text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute top-full right-0 rounded-lg p-3 mt-1 shadow-md scale-y-0 group-focus:scale-y-100 origin-bottom duration-200 z-10">
                <pre class = "active text-red-300 bg-amber-950 rounded text-left px-5 py-10 w-200">               
        //Create a two-parametered function that prints Full Name.

        function fullName($first, $last) {
            echo "Full Name: <mark>$first</mark>" . ' ' . "<mark>$last</mark>.";
        }
        fullName('John', 'Doe');
        fullName('Sara', 'Smith');
        fullName('Ali', 'Khan');
        fullName('Nour', 'Fahmy');
        fullName('David','Brown');
                </pre>
                <a href="" class = " text-amber-200 w-200"><p class = "bg-red-700">Close</p></a>
            </div>
        </button>
    </div>

    <div class = "relative flex justify-between items-center px-10 py-5 bg-teal-800 text-teal-300 text-xl">
        <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
        bg-sky-950  text-center transition delay-150 hover:opacity-0 hover:transition-opacity"><h1>Products</h1></div>
        <div class = "font-bold">
            <?php
                ###Create a function called product to define produts with their prices.
                function product($product, $price) {
                    echo "Product: $product," . " " . "Price: $ $price" . "<br />";
                }
                product('Laptop', 1200);
                product(price: 800, product: 'Phone');
                product('Tablet', 600);
                product(price: 300, product: 'Monitor');
                product('Keyboard', 100);
            ?>
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-gray-500 text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute top-full right-0 rounded-lg p-3 mt-1 shadow-md scale-y-0 group-focus:scale-y-100 origin-top duration-200 z-10">
                <pre class = "active text-yellow-300 bg-yellow-800 rounded text-left px-5 py-10 w-200">               
        ###Create a function called product
        to define produts with their prices.

        function product($product, $price) {
            echo "Product: <mark>$product</mark>," . " " . "Price: $<mark>$price</mark>";
        }
        product('Laptop', 1200);
        product(price: 800, product: 'Phone');
        product('Tablet', 600);
        product(price: 300, product: 'Monitor');
        product('Keyboard', 100);
                </pre>
                <a href="" class = " text-green-800 w-200"><p class = "bg-green-300">Close</p></a>
            </div>
        </button>
    </div>

    <div class = "relative flex justify-between items-center px-10 py-5 text-gray-900 bg-gray-400 text-xl">
        <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
        bg-gray-950 text-gray-400  text-center transition delay-150 hover:opacity-0 hover:transition-opacity"><h1>Books</h1></div>
        <div class = "font-bold">
            <?php
                //Create a function with title, and author as parameters to define books by their owners.
                function book($title, $author) {
                    echo "Title: $title," . " " ."Author: $author" . "<br />";
                }
                book('Harry Potter', 'J.K. Rowling');
                book('1984', author: 'George Orwell');
                book('The Hobbit', 'J.R.R. Tolkien');
                book('Pride and Prejudice', 'Jane Austen');
                book(author: 'Moby Dick', title: 'Herman Melville');
            ?>  
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-gray-500 text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute right-full bottom-0 rounded-lg p-3 mt-1 shadow-md scale-y-0 group-focus:scale-y-100 origin-right duration-200 z-10">
                <pre class = "active bg-red-300 text-amber-950 rounded text-left px-5 py-10 w-200">               
        //Create a function with title,
        and author as parameters to define books by their owners.

        function book($title, $author) {
            echo "Title: <mark>$title</mark>," . " " ."Author: <mark>$author</mark>";
        }
        book('Harry Potter', 'J.K. Rowling');
        book('1984', author: 'George Orwell');
        book('The Hobbit', 'J.R.R. Tolkien');
        book('Pride and Prejudice', 'Jane Austen');
        book(author: 'Moby Dick', title: 'Herman Melville');
                </pre>
                <a href="" class = " text-blue-600 w-200"><p class = "bg-blue-300">Close</p></a>
            </div>
        </button>
    </div>

    <div class = "relative flex justify-between items-center px-10 py-5 bg-violet-700 text-violet-300 text-xl">
    <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
    bg-sky-950  text-center transition delay-100 hover:opacity-0 hover:transition-opacity"><h1>Contacts</h1></div>
        <div class = "font-bold">
            <?php
                ###Create a function that shows each name with his/her mobile phone number.
                function contact($name, $phone) {
                    echo "Name: $name," . " " . "Phone: $phone" . "<br />";
                }
                contact('Ahmed', 123456789);
                contact(phone: 987654321,name: 'Sara');
                contact('Hassan', 111222333);
                contact(phone: 555666777, name: 'Nadia');
                contact('Youssef', 999888777);           
            ?>
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-gray-500 text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute bottom-full right-0 rounded-lg p-3 mt-1 shadow-md scale-y-0 group-focus:scale-y-100 origin-top duration-200 z-10">
                <pre class = "active text-teal-400 bg-teal-950 rounded text-left px-5 py-10 w-200">               
        ###Create a function that shows each name
        with his/her mobile phone number.

        function contact($name, $phone) {
            echo "Name: <mark>$name</mark>," . " " . "Phone: <mark>$phone</mark>";
        }
        contact('Ahmed', 123456789);
        contact(phone: 987654321,name: 'Sara');
        contact('Hassan', 111222333);
        contact(phone: 555666777, name: 'Nadia');
        contact('Youssef', 999888777); 
                </pre>
                <a href="" class = "text-amber-200 w-200"><p class = "bg-red-400">Close</p></a>
            </div>
        </button>
    </div>
    
    <div class = "relative flex justify-between items-center px-10 py-5 bg-purple-300 text-purple-700 text-xl">
    <div class = "text-7xl absolute p-10 w-full left-0 h-full backdrop-opacity-95
    bg-pink-950 text-pink-200  text-center transition delay-150 hover:opacity-0 hover:transition-opacity"><h1>Movies</h1></div>
        <div class = "font-bold">
            <?php
                //Create a function with two parameters that prints the name of a movie and gives a message "it's an old movie" in condition if that movie's year < 2010 .
                function movie($movie, $year) {
                    if ($year < 2010) {
                        echo "Movie: $movie, " . " " . "Year: $year, " . "it's an old movie." . "<br />";}
                
                    else {
                        echo "Movie: $movie, " . " " . "Year: $year, " . "it's a later movie." . "<br />";
                    }
                }   
                movie('Inception', 2010);
                movie(year: 1997, movie: 'Titanic', );
                movie(year: 2009, movie: 'Avatar');
                movie('Interstellar', 2014);
                movie('The Matrix', 1999);
            ?>
        </div>
        <div class = "flex flex-col items-center justify-around">
            <p font-bold>Towards The Code</p>
            <img src="../aspects/arrow.png" alt="arrow" class="w-20">
        </div>
        <button class="group relative border border-gray-300 bg-white text-black text-lg px-3 py-2 rounded">
            Show The Code
            <div class = "absolute bottom-full right-0 rounded-lg p-4 mt-1 shadow-md scale-y-0 group-focus:scale-y-100  origin-bottom duration-200 z-10">
                <pre class = "active text-yellow-700 bg-yellow-200 rounded text-left px-5 py-10 w-200">               
        //Create a function with two parameters that prints
        the name of a movie and gives a message "it's an old movie"
        in condition if that movie's year < 2010.

        function movie($movie, $year) {
            if ($year < 2010) {
                echo "Movie: <mark>$movie</mark>, "
                 . " " . "Year: <mark>$year</mark>, "
                  . "it's an old movie.";}
        
            else {
                echo "Movie: <mark>$movie</mark>, "
                 . " " . "Year: <mark>$year</mark>, "
                  . "it's a later movie.";
            }
        }   
        movie('Inception', 2010);
        movie(year: 1997, movie: 'Titanic', );
        movie(year: 2009, movie: 'Avatar');
        movie('Interstellar', 2014);
        movie('The Matrix', 1999);
                </pre>
                <a href="" class = "text-cyan-800 w-200"><p class = "bg-green-300">Close</p></a>
            </div>
        </button>
    </div>


</body>
</html>
















