<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practice</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="coding.jfif">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
    
</head>
<body>
    <div class="container-fluid">  
        <h1 class="md-5 h1">Welcome In My Site</h1>
        
        <p class="navbar gap-2">
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample1>1# Addition Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample2>2# Multiplication Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample3>3# Division Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample4>4# Area Calculation Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample5>5# Getting Square Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample6>6# Getting cube Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample7>7# Converting To Minutes Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample8>8# Converting To Seconds Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample9>9# Calculating Perimeter Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample10>10# Getting Average Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample11>11# Converting Tempreture Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample12>12# Speed Calculation Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target = #multiCollapseExample13>13# Getting Hypotenuse Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample14>14# Power Raising Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample15>15# Getting Remainder Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample16>16# Calculating BMI Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample17>17# Converting To Kilometers Function</button>

        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample18>18# Calculating Interests Function</button>
        
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample19>19*# Finding Precentage Function</button>
        
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=#multiCollapseExample20>20# Calculating Compound Function</button>
        </p>
        <div class="row">
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample1">
                <div class="card card-body text-bg-info p-6">
                    <?php 
                        ### 1. Write a function `addNumbers` that takes two numbers as parameters and returns their sum.  
                        function addNumbers($a, $b) {
                            $d = $a + $b;
        
                            return "The Sum of <span>$a</span>  and <span>$b</span>  equals  " . "<span> $a + $b = $d </span>" . "<hr />";
                        }
                        echo  addNumbers(12, 20);
                        print addNumbers(16, 18);
                        print addNumbers(69.15, 13.89);     
                    ?>
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample2">
                <div class="card card-body text-bg-dark p-4">    
                    <?php 
                        function multiply($a, $b, $c) {
                            $d = $a * $b * $c;
        
                            return "The Multiplication of <span>$a</span> , <span>$b</span> and <span>$c</span>  equals  " . "<span> $a * $b * $c = $d </span>" . "<hr />";
                        }
                        echo multiply(10, 20, 30);
                        echo multiply(6, 78, 13);
                        echo multiply(69, 10.8, 4.698);
                    ?>       
                </div>                                 
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse text-bg-success p-6" id="multiCollapseExample3">
                <div class="card card-body text-bg-light p-6 ">
                    <?php
                        ### 3. Implement a function `divide` that divides two numbers and returns the quotient.
                        function divide($a, $b) {
                            $d = $a + $b;

                            if ($b === 0) {
                                Echo "We can't divide by <span>0</span>You wanted to divide <span>$a</span> by <span>0</span> and that's not allowed" . "<hr />.";
                            }
                            else {
                                return "The division of <span>$a</span>  and <span>$b</span>  equals  " . "<span> $a / $b = $d </span>" . "<hr />";
                            }

                        }
                        print divide(268, 0);
                        print divide(15556980, 125463);
                        print divide(8000, 20.80);
                    ?>          
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample4">
                <div class="card card-body text-bg-warning p-6">
                    <?php
                        ### 4. Write a function `calculateArea` to find the area of a rectangle given its width and height.
                        function calculateArea($width, $height) {
                            $area = $width * $height;

                            return "The Area of the rectangle which its width is <span>$width m</span> , and its height is <span>$height m</span> equals " . "<span>$width * $height = $area m<sup>2</sup> </span>" . "<hr />";
                        }
                        Print calculateArea(20, 40);
                        Print calculateArea(15, 24);
                        Print calculateArea(43.7, 80.5);
                    ?>
                </div>     
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample5">
                <div class="card card-body text-bg-dark p-6">
                    <?php
                        ### 5. Create a function `square` that takes one number as input and returns its square.
                        function square($number) {
                            $squared = $number ** 2;
                            return "The Square of the number <span>$number</span> equals " . "<span>$number ** 2  ===> ($number * $number) = $squared</span>" . "<hr />";
                        }
                        ECHO square(10);
                        ECHO square(50);
                        ECHO square(347.258);
                    ?>
                </div>                
            </div>
            </div>
            
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample6">
                <div class="card card-body text-bg-dark p-6">
                    <?php
                        ### 6. Write a function `cube` to calculate the cube of a number.
                        function cube($number) {
                            $cubed = $number ** 3;
                            return "The cube of the number <span>$number</span> equals " . "<span>$number ** 3 ===> ($number * $number * $number) = $cubed</span>" . "<hr />";
                        }
                        ECHO cube(12);
                        ECHO cube(25);
                        ECHO cube(19.789);
                    ?>

                </div> 
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample7">
                <div class="card card-body text-bg-secondry p-6">
                    <?php
                        ### 7. Implement a function `convertToMinutes` that converts hours to minutes.
                        function convertToMinutes($hours) {
                            $minutes = $hours * 60;
                            return "The amount of hours that equals <span>$hours hours</span> becomes " . "<span>$hours * 60 = $minutes minutes</span>" . "<hr />";
                        }
                        PrinT convertToMinutes(24);
                        PrinT convertToMinutes(36);
                        PrinT convertToMinutes(248);
                    ?>
                </div>
            </div>                  
            </div>
        
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample8">
                <div class="card card-body text-bg-danger p-6">
                    <?php
                        ### 8. Write a function `convertToSeconds` that converts days to seconds.
                        function convertToSeconds($days) {
                                $seconds = $days * 24 * 60 * 60;
                                return "The amount of days that equals <span>$days days</span> becomes " . "<span>$days * 24 * 60 * 60 = $seconds seconds</span>" . "<hr />";
                        }
                        EcHo convertToSeconds(10);
                        EcHo convertToSeconds(5);
                        EcHo convertToSeconds(365);
                    ?>
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample9">
                <div class="card card-body text-bg-light p-6">
                    <?php
                        ### 9. Create a function `calculatePerimeter` for the perimeter of a rectangle, given width and height.
                        function calculatePerimeter($width, $height) {
                            $perimeter = ($width + $height) * 2;
                            return "The Perimeter of some rectangle with width = <span>$width cm</span> and height = <span>$height cm</span> is <span>($width + $height) * 2 = $perimeter cm</span>" . "<hr />";
                        }
                        PRINT calculatePerimeter(20, 50);
                        PRINT calculatePerimeter(19.78, 23);
                        PRINT calculatePerimeter(76, 98);
                    ?>
                </div>                       
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample10">
                <div class="card card-body text-bg-primary p-6">
                    <?php
                        ### 10. Write a function `average` to calculate the average of three numbers.
                        function average($a, $b, $c) {
                            $averageNumber = ($a + $b + $c ) / 3;
                            return "The average of these three numbers <span>$a, $b, $c</span> equals <span>($a + $b + $c ) / 3 = $averageNumber </span>" . "<hr />"; 
                        }
                        EChO average(10, 20, 30);
                        EChO average(12, 25, 39);
                        EChO average(4569.245, 2656.15, 7895.54);
                    ?>
                </div>                       
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample11">
                <div class="card card-body text-bg-info p-6">
                    <?php
                        ### 11. Create a function `convertTemperature` to convert Celsius to Fahrenheit.
                        function convertTemperature($celsius) {
                            $tempInFehr = $celsius * (9 / 5) + 32;
                            return "The Tempreture in Fehrenheit from Celsius one equals <span>$celsius °C</span> is <span>$celsius * (9 / 5) + 32 = $tempInFehr °F</span>" . "<hr />";
                        }
                        Echo convertTemperature(25);
                        Echo convertTemperature(32);
                        Echo convertTemperature(50);
                    ?>
                </div>
            </div>
            </div>

            <div class="col">
            <div class="collapse multi-collapse" id="multiCollapseExample12">
                <div class="card card-body text-bg-dark p-6">
                    <?php
                        ### 12. Implement a function `calculateSpeed` that calculates speed given distance and time.
                        function calculateSpeed($distance, $time) {
                            $speed = $distance / $time;
                            return "The speed of the vehecle which is walking in a distance <span>$distance km</span> in a time <span>$time h</span> equals <span>$distance / $time = $speed km/h</span>" . "<hr />";
                        }
                        Print calculateSpeed(20, 0.5);
                        Print calculateSpeed(300, 2.5);
                        Print calculateSpeed(1800, 4);
                    ?>                   
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample13">
                <div class="card card-body text-bg-warning p-6">
                    <?php
                        ### 13. Write a function `hypotenuse` that calculates the hypotenuse of a right triangle given its two sides.
                        function hypotenuse($sideA, $sideB) {
                            $squaredHypo = $sideA ** 2 + $sideB ** 2;
                            $squareRootHypo =  sqrt($squaredHypo);
                            return "The Hypotenuse of a right triangle given its two sides : <span> $sideA m , $sideB m</span> equals, the square root of <span>Squared Hypotenuse = $sideA ** 2 + $sideB ** 2 = $squaredHypo m<sup>2</sup></span>" . "Then the Hypotenuse = the square root of <span>$squaredHypo = $squareRootHypo </span>" . "<hr />"; 
                        }
                        Echo hypotenuse(20, 30);
                        Echo hypotenuse(68, 57);
                        Echo hypotenuse(33, 44);
                    ?>                  
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample14">
                <div class="card card-body text-bg-success p-6">
                    <?php
                        ### 14. Create a function `power` that raises a number to a given exponent.
                        function power($base, $exponent) {
                            $power = pow($base, $exponent);
                            return "The power that raises the number <span> $base </span> to the exponent <span> $exponent </span> equals <span> $power </span>" . "<hr />";
                        }
                        Echo power(30, 5);
                        Echo power(8, 7);
                        Echo power(2, 20);
                    ?>                  
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample15">
                <div class="card card-body text-bg-light p-6">
                    <?php
                        ### 15. Write a function `modulus` to find the remainder when one number is divided by another.
                        function modulus($a, $b) {
                            $remainder = $a % $b;
                            return "The remainder from dividing <span>$a</span> by <span>$b</span> equals <span>$remainder</span>" . "<hr />";
                        }
                        PrInT modulus(20, 3);
                        PrInT modulus(589, 45);
                        PrInT modulus(87878215, 2345);
                    ?>                  
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample16">
                <div class="card card-body text-bg-danger p-6">
                    <?php
                        ### 16. Implement a function `calculateBMI` that calculates the Body Mass Index given weight and height.
                        function calculateBMI($weight, $height) {
                            $bmi = $weight / ($height ** 2);
                            return "The Body Mass Index of somebody or something weights <span>$weight kg</span> and his/her/its height is <span>$height m</span> equals <span>$weight / ($height ** 2) = $bmi kg/m<sup>2</sup></span>" . "<hr />";
                        }
                        echo calculateBMI(80, 175);
                        echo calculateBMI(60, 162);
                        echo calculateBMI(5, 2);
                    ?>                  
                </div>
            </div>
            </div>
            
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample17">
                <div class="card card-body text-bg-info p-6">
                    <?php
                        ### 17. Create a function `convertToKilometers` to convert meters to kilometers.
                        function convertToKilometers($meters) {
                            $kilometers = $meters / 1000;
                            return "The amount of <span>$meters m</span> equals <span>$meters / 1000 = $kilometers km</span>" . "<hr/ >";
                        }
                        echo convertToKilometers(5);
                        echo convertToKilometers(8000364);
                        echo convertToKilometers(70000);
                    ?>                  
                </div>
            </div>
            </div>
            
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample18">
                <div class="card card-body text-bg-primary p-6">
                    <?php
                        ### 18. Write a function `calculateInterest` to calculate simple interest given principal, rate, and time.
                        function calculateInterest($principal, $rate, $time) {
                            $interest = ($principal * $rate * $time) / 100;
                            return "The Interests of the company which has borrowed a loan amounted <span>$ $principal </span> and the rate of the interests is <span>$rate %</span> for a time duration <span>$time year 's'</span> equals <span>($principal * $rate * $time) / 100 = $ $interest</span>" . "<hr />";
                        } 
                        print calculateInterest(80000000, 12, 1);          
                        print calculateInterest(120000000000, 17, 3);          
                        print calculateInterest(56000000, 10.5, 2);          
                    ?>                  
                </div>
            </div>
            </div>
            
            
            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample19">
                <div class="card card-body text-bg-secondry p-6">
                    <?php
                    ### 20. Implement a function `findPercentage` that calculates the percentage of a given value out of a total.
                    function findPercentage($value, $total) {
                        $precentage = ($value / $total) * 100;
                        return "the precentage of the given value <span>$value</span> out of the total <span>$total</span> equals <span>($value / $total) * 100 = $precentage %</span>" . "<hr />";
                    }
                    echo findPercentage(8000, 90000);
                    echo findPercentage(700, 2000);
                    echo findPercentage(60000, 10000000);
                    ?>    
                </div>
            </div>
            </div>

            <div class="col-12">
            <div class="collapse multi-collapse" id="multiCollapseExample20">
                <div class="card card-body text-bg-dark p-6">
                    <?php
                        ### 19. Create a function `compoundInterest` that calculates compound interest given principal, rate, and time.
                        function compoundInterest($principal, $rate, $time) {
                            return "Compound Interest Formula equals <span> A = P(1+ r/n)<sup>nt</sup></span>" . "<span> Can You Help !!! 
                            Eng/Maged Yaseen Please  S.O.S </span>";
                        }
                        echo compoundInterest(800000, 12, 2);
                    ?>                  
                </div>
            </div>
            </div>

        </div>

        </div>
    </div>
</body>
</html>






































